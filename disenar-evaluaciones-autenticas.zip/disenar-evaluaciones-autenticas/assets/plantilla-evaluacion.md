# Evaluación auténtica

## 1. Datos generales

- Asignatura:
- Unidad o tema:
- Destinatarios:
- Cantidad de estudiantes:
- Modalidad educativa:
- Tipo de interacción: sincrónica, asincrónica o combinada.
- Forma de participación: individual, grupal o mixta.
- Organización de los grupos, si corresponde:
- Lugar de realización:
- Duración:
- Horario y condiciones temporales que influyen:
- Recursos, conectividad, permisos o restricciones:
- Ponderación o puntaje:

## 2. Enfoque curricular y alineación

- Organización del programa: por competencias o por objetivos.
- Competencia u objetivo de referencia:
- Criterios, capacidades, elementos o condiciones vinculadas, si corresponden:

## 3. Método de enseñanza

- Método o métodos:
- Forma concreta de integración en la evaluación:

## 4. Resultado de aprendizaje o desempeño

[Un verbo observable + contenido + condición relevante]

## 5. Sentido auténtico

[Contexto, propósito, destinatario, decisiones y relación con el aprendizaje]

## 6. Consigna para el estudiante

[Acción, situación, condiciones, recursos y resultado esperado]

## 7. Etapas y retroalimentación

| Etapa | Acción | Evidencia | Tiempo | Retroalimentación |
| --- | --- | --- | --- | --- |

## 8. Entregables

### Producto final

[Producto o desempeño]

### Evidencias del proceso

[Evidencias seleccionadas]

### Evidencia individual en trabajos grupales

[Aporte, decisión, explicación, defensa, autoevaluación u otra evidencia proporcionada]

## 9. Uso de inteligencia artificial

- Régimen: permitido, limitado o no permitido.
- Usos autorizados:
- Usos no autorizados:
- Verificación requerida:
- Declaración de uso:

## 10. Rúbrica analítica

| Criterio | Avanzado | Logrado | En proceso | Inicial | Peso |
| --- | --- | --- | --- | --- | ---: |

## 11. Autoevaluación del estudiante

1. ¿Qué decisión influyó más en la calidad del producto y por qué?
2. ¿Qué cambió después de revisar fuentes, retroalimentación o respuestas de IA?
3. ¿Qué parte del resultado demuestra mejor el aprendizaje esperado?

## 12. Lista de comprobación docente

- [ ] La evidencia permite valorar el resultado.
- [ ] La carga corresponde al tiempo y la ponderación.
- [ ] El lugar, horario, modalidad y cantidad de estudiantes permiten ejecutar la actividad.
- [ ] La organización individual o grupal concuerda con las evidencias.
- [ ] El enfoque curricular y el método se reflejan en la actividad.
- [ ] Los criterios son observables y no se solapan.
- [ ] Las reglas de IA son comprensibles y verificables.
- [ ] La actividad ofrece condiciones de acceso y participación.
- [ ] La calificación final requiere revisión docente.

## 13. Accesibilidad

[Alternativas equivalentes, formatos accesibles, apoyos y ajustes pertinentes]

## 14. Versión breve para Moodle

**Propósito:**

**Tarea:**

**Etapas y fechas:**

**Modalidad, lugar y organización:**

**Entregables:**

**Uso de IA:**

**Criterios de evaluación:**

**Forma de entrega:**
