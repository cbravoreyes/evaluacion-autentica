# Contexto curricular y metodológico

Leer al reunir los datos iniciales y antes de redactar la actividad. Usar los campos solo si cambian una decisión de la evaluación.

## Contexto de aplicación

| Campo | Opciones frecuentes | Decisión que debe modificar |
| --- | --- | --- |
| Lugar | Aula, laboratorio, espacio especializado, entorno comunitario o profesional, fuera de la institución, entorno virtual | Recursos, permisos, seguridad, desplazamiento, observación y forma de entrega |
| Horario | Franja habitual, turno nocturno, bloque intensivo, tiempo limitado, horario flexible | Duración de etapas, pausas, sincronía, atención y retroalimentación |
| Cantidad de estudiantes | Grupo pequeño, mediano o numeroso | Formación de equipos, seguimiento, retroalimentación y volumen de evidencias |
| Modalidad | Presencial, a distancia o híbrida; sincrónica, asincrónica o combinada | Canales de interacción, acceso, demostración del desempeño y contingencias |
| Participación | Individual, grupal o mixta | Responsabilidad, colaboración, entregables y evidencia individual |

No suponer que el horario influye. Preguntar si crea una condición real, como menor tiempo disponible, acceso restringido al laboratorio, traslado, conectividad o imposibilidad de reunir a los equipos.

En una evaluación grupal, precisar número de integrantes, criterio de conformación, roles si son necesarios y evidencia individual. Evitar multiplicar registros de control sin valor formativo.

## Enfoque curricular

### Programa por competencias

Solicitar la competencia o desempeño y, cuando existan, sus criterios, capacidades, elementos o saberes vinculados. Alinear la situación y las evidencias con una actuación integrada ante condiciones definidas. No reducir la competencia a una lista de contenidos.

### Programa por objetivos

Solicitar el objetivo de la unidad o actividad. Identificar acción, contenido y condiciones. Formular un resultado observable solo si ayuda a diseñar la evidencia y someterlo a aprobación docente.

No exigir simultáneamente competencia y objetivo. Respetar la terminología del programa proporcionado por el docente y señalar cualquier ambigüedad antes de reemplazarla.

## Métodos de enseñanza

Preguntar si la evaluación se inserta en un método ya definido. Si el docente no lo ha decidido y la elección cambia la actividad, ofrecer pocas opciones con una consecuencia clara:

- **Métodos problémicos:** organizar la evaluación alrededor de una situación contradictoria, una pregunta problémica, búsqueda argumentada y propuesta sustentada.
- **Métodos grupales:** definir interdependencia, interacción, responsabilidad compartida y evidencia individual proporcionada.
- **Estudio de casos:** presentar información contextual, decisiones posibles, criterios y justificación de la respuesta.
- **Proyectos:** articular un producto, etapas, revisión y respuesta a una necesidad delimitada.
- **Investigación:** incorporar pregunta, fuentes o datos, procedimiento, interpretación y comunicación de hallazgos.
- **Otros métodos:** pedir nombre y rasgos operativos; traducirlos a acciones observables antes de incorporarlos.

No agregar un método por apariencia pedagógica. Integrarlo solo si modifica la secuencia, la interacción, las evidencias o los criterios.
