# Diseño de rúbricas analíticas

Leer al convertir las evidencias en criterios y niveles de desempeño.

## Procedimiento

1. Derivar entre cuatro y seis criterios del resultado, el producto y el proceso.
2. Formular cada criterio como una cualidad observable, no como un tema.
3. Evitar criterios que se solapen.
4. Asignar mayor peso a la evidencia central del aprendizaje.
5. Describir cuatro niveles de desempeño mediante diferencias de calidad.
6. Comprobar que las ponderaciones sumen 100 %.

## Estructura recomendada

| Criterio | Avanzado | Logrado | En proceso | Inicial | Peso |
| --- | --- | --- | --- | --- | ---: |
| Cualidad observable | Cumplimiento sólido y justificado | Cumplimiento suficiente con fallas menores | Cumplimiento parcial o inconsistente | Evidencia insuficiente o no pertinente | % |

Sustituir estas fórmulas generales por descriptores propios de la actividad.

## Reglas para los descriptores

- Describir qué se observa, no rasgos personales del estudiante.
- Usar diferencias verificables: exactitud, profundidad, coherencia, pertinencia, justificación, integración o autonomía.
- Evitar términos aislados como “excelente”, “regular” o “deficiente”.
- No definir un nivel solo mediante ausencia de errores.
- Mantener un único foco por criterio.
- Incluir presentación o corrección lingüística solo si afectan el resultado o su comunicación.

## Ponderación orientativa

Adaptar al resultado y no aplicar mecánicamente:

- Evidencia central del producto: 50 a 70 %.
- Proceso y toma de decisiones: 20 a 35 %.
- Reflexión, revisión o comunicación: 10 a 20 %.

No calificar cantidad de prompts, uso frecuente de IA ni longitud del historial. Valorar la pertinencia de las decisiones y la verificación realizada.
