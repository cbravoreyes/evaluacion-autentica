# Principios de evaluación auténtica

Leer al construir o transformar la actividad evaluativa.

## Rasgos operativos

Una evaluación auténtica combina varios de estos rasgos, sin exigirlos todos:

- Sitúa el conocimiento en un problema, caso, encargo o práctica reconocible.
- Define un propósito y un destinatario del producto.
- Exige seleccionar, aplicar, relacionar, crear, argumentar o valorar.
- Incluye restricciones semejantes a las del contexto de uso.
- Admite decisiones justificadas y más de una respuesta defendible cuando el resultado lo permite.
- Produce una evidencia revisable con criterios conocidos.
- Integra retroalimentación, revisión o reflexión sobre el proceso.

La actividad no es auténtica solo por usar una herramienta digital, simular una profesión o producir un recurso atractivo.

## Matriz de alineación

| Elemento | Pregunta de control |
| --- | --- |
| Resultado | ¿Qué actuación observable debe demostrar el estudiante? |
| Situación | ¿En qué contexto tendría sentido esa actuación? |
| Consigna | ¿Qué decisiones y acciones debe realizar? |
| Producto | ¿Qué resultado tangible o desempeño se observará? |
| Proceso | ¿Qué huellas permiten interpretar cómo llegó al resultado? |
| Criterios | ¿Qué cualidades distinguen un desempeño logrado? |

## Transformar una tarea tradicional

1. Identificar qué aprendizaje buscaba observar la tarea original.
2. Eliminar componentes que solo exijan recordar o copiar, salvo que sean necesarios.
3. Añadir contexto, propósito, destinatario, restricciones y decisiones.
4. Pedir aplicación o juicio sustentado mediante evidencias.
5. Incorporar una oportunidad de revisión y una explicación breve de decisiones.
6. Conservar una carga de trabajo proporcional a su ponderación.

## Seleccionar el nivel cognitivo

Usar Bloom como control de coherencia, no como etiqueta decorativa:

- **Aplicar:** emplear procedimientos o conceptos ante un caso nuevo.
- **Analizar:** distinguir componentes, relaciones, supuestos o causas.
- **Evaluar:** emitir un juicio mediante criterios y evidencias.
- **Crear:** producir una solución coherente con condiciones definidas.

Evitar incluir varios verbos principales si el resultado pretende evaluar un desempeño central.
