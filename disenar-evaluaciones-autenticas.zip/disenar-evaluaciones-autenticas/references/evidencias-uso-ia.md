# Evidencias y uso de IA

Leer cuando la evaluación permita, limite o estudie el empleo de inteligencia artificial.

## Definir el régimen de uso

| Régimen | Aplicación |
| --- | --- |
| Permitido | La IA puede apoyar varias etapas; exigir verificación y declaración de uso. |
| Limitado | Indicar etapas, funciones o herramientas autorizadas y las no autorizadas. |
| No permitido | Explicar la razón pedagógica y ofrecer condiciones realistas para realizar la tarea. |

No equiparar el uso de IA con deshonestidad. Evaluar el aprendizaje demostrado y el cumplimiento de las reglas comunicadas.

## Seleccionar evidencias pertinentes

Elegir solo las que ayuden a interpretar el aprendizaje:

- Fuentes consultadas y criterio de selección.
- Preguntas o prompts decisivos, no el historial completo.
- Fragmento de respuesta de IA que influyó en una decisión.
- Verificación de una afirmación, dato o referencia.
- Cambios introducidos y razón de esos cambios.
- Borrador o versión intermedia relevante.
- Justificación de una decisión conceptual, metodológica o de diseño.
- Declaración breve de herramientas y funciones utilizadas.
- Autoevaluación sobre aportes, errores y límites de la IA.

## Ruta visible del aprendizaje

Organizar la evidencia en cuatro momentos cuando resulte pertinente:

1. **Buscar:** fuentes, preguntas y criterios de selección.
2. **Analizar:** contraste, organización y detección de problemas.
3. **Decidir:** elecciones justificadas y cambios realizados.
4. **Revisar:** retroalimentación, correcciones y reflexión final.

## Privacidad e integridad

- Solicitar extractos relevantes en lugar de conversaciones completas.
- Evitar datos personales o sensibles del estudiante y de terceros.
- Verificar citas y referencias antes de aceptarlas.
- Tratar detectores de IA como señales falibles, nunca como prueba concluyente.
- Reservar a la persona docente las decisiones de calificación, autoría e integridad académica.
- Permitir tecnologías de apoyo cuando no sustituyan el desempeño evaluado.
