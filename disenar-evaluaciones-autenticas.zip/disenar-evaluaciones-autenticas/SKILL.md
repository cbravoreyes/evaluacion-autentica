---
name: disenar-evaluaciones-autenticas
description: Diseña evaluaciones auténticas para educación superior con situación contextualizada, consigna, etapas, evidencias del producto y del proceso, uso transparente de IA, retroalimentación, rúbrica analítica y versión breve para Moodle. Usar cuando un docente pida crear una evaluación auténtica, transformar una prueba o tarea tradicional en desempeño situado, evaluar producto y proceso, incorporar la ruta visible del aprendizaje o diseñar una actividad evaluativa resistente a la copia directa con IA. No usar para generar únicamente bancos de preguntas, calificar trabajos automáticamente, detectar plagio ni elaborar una rúbrica aislada sin diseñar la evaluación completa.
---

# Diseñar evaluaciones auténticas

Construir evaluaciones que permitan al estudiante actuar ante una situación significativa, producir una evidencia y justificar decisiones. Mantener alineados resultado de aprendizaje, situación, actividad, evidencias y criterios.

## Seleccionar el modo de trabajo

- **Diseño guiado:** usar cuando falten datos o el docente pida acompañamiento. Formular una pregunta breve por turno y ofrecer opciones cuando faciliten la decisión.
- **Diseño directo:** usar cuando la solicitud ya incluya los datos necesarios. Entregar una propuesta completa y marcar solo las decisiones que requieran confirmación.

No repetir preguntas ya respondidas. No detener el diseño por datos secundarios; declarar supuestos reversibles y pedir confirmación solo si una decisión cambia materialmente el resultado.

## Reunir la información necesaria

Identificar:

1. Asignatura, unidad y contenido.
2. Destinatarios, cantidad de estudiantes y características relevantes para aprender.
3. Enfoque curricular: programa por competencias o por objetivos; competencia, objetivo, resultado de aprendizaje o desempeño esperado que corresponda.
4. Modalidad educativa: presencial, a distancia o híbrida; sincrónica, asincrónica o combinada cuando corresponda.
5. Forma de participación: individual, grupal o mixta; tamaño y organización de los grupos si se conocen.
6. Lugar de realización: aula, laboratorio, espacio institucional especializado, entorno comunitario o profesional, fuera de la institución o entorno virtual.
7. Duración, horario y condiciones temporales que influyan en la evaluación.
8. Recursos, conectividad, movilidad, permisos y restricciones del lugar.
9. Métodos de enseñanza vinculados: problémicos, grupales, proyectos, casos, investigación u otros definidos por el docente.
10. Producto o desempeño previsto, si existe.
11. Uso permitido, limitado o no permitido de IA.
12. Puntaje, ponderación y requisitos institucionales, si fueron definidos.

No inventar resultados de aprendizaje, reglamentos ni condiciones institucionales. Si falta el resultado, ayudar a formular una propuesta con un solo verbo observable y solicitar aprobación docente.

En diseño guiado, agrupar las preguntas relacionadas para evitar un interrogatorio extenso. Preguntar por la influencia del horario, el lugar o el método solo cuando pueda modificar la consigna, las etapas, los recursos, la participación, las evidencias o los criterios. Leer [contexto curricular y metodológico](references/contexto-curricular-metodologico.md) para interpretar estos datos y convertirlos en decisiones de diseño.

## Diseñar la evaluación

1. **Analizar la alineación curricular.** Distinguir si el programa se organiza por competencias o por objetivos. Identificar el desempeño, verbo, contenido, condición y nivel cognitivo; no convertir ambos enfoques en campos obligatorios simultáneos.
2. **Interpretar las condiciones de aplicación.** Traducir cantidad de estudiantes, modalidad, participación, lugar, horario, recursos y método de enseñanza en decisiones sobre organización, tiempos, apoyos, evidencias y retroalimentación.
3. **Plantear la situación auténtica.** Definir destinatario, propósito, contexto, decisiones y restricciones semejantes a un uso académico, profesional o social del aprendizaje. Leer [principios de evaluación auténtica](references/principios-evaluacion-autentica.md).
4. **Redactar la consigna.** Explicar qué debe realizar el estudiante, para quién, con qué recursos, en qué lugar, de qué forma participará, en qué etapas y bajo qué condiciones.
5. **Definir producto y proceso.** Separar la evidencia final de las huellas que permiten revisar investigación, decisiones, revisión y autoría. En trabajos grupales, incluir una evidencia razonable de aprendizaje individual.
6. **Integrar el método de enseñanza.** Hacer que el método seleccionado determine acciones, interacción o secuencia. No limitarse a nombrarlo en los datos generales.
7. **Regular el uso de IA.** Seleccionar evidencias pertinentes según [evidencias y uso de IA](references/evidencias-uso-ia.md). No exigir todas por defecto.
8. **Incorporar retroalimentación.** Añadir al menos un punto de revisión antes de la entrega final cuando la duración, el horario y el número de estudiantes lo permitan; proponer una modalidad viable de retroalimentación.
9. **Crear la rúbrica.** Aplicar [diseño de rúbricas](references/diseno-rubricas.md). Vincular cada criterio con una evidencia y asignar ponderaciones que sumen 100 %.
10. **Revisar viabilidad y acceso.** Comprobar carga de trabajo, espacio, desplazamiento, seguridad, permisos, conectividad, recursos, claridad, privacidad y opciones equivalentes de participación o expresión cuando el formato no sea parte del aprendizaje.

## Entregar el resultado

Usar [la plantilla](assets/plantilla-evaluacion.md) y completar:

1. Datos generales.
2. Contexto de aplicación y organización de los estudiantes.
3. Enfoque curricular y referente de alineación.
4. Método o métodos de enseñanza integrados.
5. Resultado de aprendizaje o desempeño revisado.
6. Justificación breve de la autenticidad.
7. Situación y consigna para el estudiante.
8. Etapas, tiempos y retroalimentación.
9. Producto final y evidencias del proceso.
10. Reglas de uso de IA y declaración de autoría.
11. Rúbrica analítica.
12. Autoevaluación breve.
13. Lista de comprobación docente.
14. Alternativas de accesibilidad.
15. Versión breve para Moodle.

Cerrar con **Decisiones que debe confirmar el docente**, solo cuando existan aspectos pendientes. No asignar la calificación final ni afirmar que una evidencia demuestra plagio, autoría o aprendizaje sin revisión humana.

## Control de calidad

Antes de entregar, comprobar:

- El resultado usa una acción observable y la evidencia permite juzgarla.
- La situación exige aplicar conocimientos y tomar decisiones, no solo reproducir información.
- La dificultad corresponde al nivel, tiempo y recursos.
- El lugar, horario, modalidad y número de estudiantes se traducen en condiciones realizables.
- La forma individual, grupal o mixta concuerda con el resultado y las evidencias.
- Si la actividad es grupal, existe una forma proporcionada de valorar el aprendizaje individual.
- El enfoque por competencias u objetivos se refleja en la alineación sin mezclar terminologías innecesariamente.
- El método de enseñanza declarado modifica acciones, interacción o secuencia.
- Producto, proceso y criterios están diferenciados.
- Cada criterio valora un aspecto distinto y describe calidad observable.
- El empleo de IA está permitido, limitado o excluido de forma explícita.
- Las evidencias de IA ayudan a comprender el proceso y no se convierten en vigilancia desproporcionada.
- La revisión docente permanece en calificación, autoría, integridad académica y adaptaciones sensibles.
- La versión para Moodle conserva la consigna, entregables, fechas o etapas y criterios centrales.

## Límites

- No convertir toda evaluación en un proyecto extenso.
- No imponer un producto digital si el resultado no lo requiere.
- No confundir novedad tecnológica con autenticidad.
- No exigir datos personales ni historiales de conversación completos con una IA.
- No usar detectores automáticos como prueba concluyente de autoría o plagio.
- No penalizar el uso permitido de tecnologías de apoyo.
- Redirigir solicitudes de cuestionarios aislados, calificación automática o rúbricas independientes hacia una herramienta apropiada.
